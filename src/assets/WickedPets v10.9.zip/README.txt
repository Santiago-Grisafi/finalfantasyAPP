Drag and drop the files into your Mods folder

The Sims 4/Mods